package Game;

public class Run {
	public static void main(String[]args) {
		gameMenu first=new gameMenu();
		
		first.GameStart();
	
	
	
	}

}
